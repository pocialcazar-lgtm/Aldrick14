// 📁 plugins/group-pinmsg.js

let pinned = {}

let handler = async (m, { command, conn, text }) => {
  const chatId = m.chat

  if (command === 'pinmsg') {
    if (!m.quoted) return m.reply('❗ Balas pesan yang ingin kamu pin.')
    if (!m.quoted.text) return m.reply('❌ Tidak bisa pin pesan tanpa teks.')

    pinned[chatId] = {
      text: m.quoted.text,
      sender: m.quoted.sender,
      id: m.quoted.id
    }
    return m.reply('✅ Pesan berhasil dipin!')
  }

  if (command === 'cekpin') {
    if (!pinned[chatId]) return m.reply('📌 Tidak ada pesan yang di-pin.')
    let pin = pinned[chatId]
    return m.reply(`📌 *Pesan Ter-pin:*\n${pin.text}`)
  }

  if (command === 'unpinmsg') {
    if (!pinned[chatId]) return m.reply('📌 Tidak ada pin yang bisa dihapus.')
    delete pinned[chatId]
    return m.reply('❎ Pesan pin telah dihapus.')
  }
}

handler.help = ['pinmsg', 'cekpin', 'unpinmsg']
handler.tags = ['group']
handler.command = ['pinmsg', 'cekpin', 'unpinmsg']
handler.group = true
handler.admin = true

module.exports = handler