let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isOwner }) => {
  if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup!'
  if (!isAdmin && !isOwner) throw 'Hanya admin yang bisa menggunakan fitur ini.'

  let chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
  chat.mutedUsers = chat.mutedUsers || []

  let user = m.mentionedJid[0] || m.quoted?.sender
  if (!user) throw `Tag pengguna yang ingin di-${command}.\n\nContoh:\n${usedPrefix + command} @user`

  switch (command) {
    case 'mute':
      if (chat.mutedUsers.includes(user)) return m.reply('👤 Pengguna sudah dalam keadaan mute.')
      chat.mutedUsers.push(user)
      m.reply(`✅ Pengguna @${user.split('@')[0]} telah di-*mute*.`, null, { mentions: [user] })
      break

    case 'unmute':
      if (!chat.mutedUsers.includes(user)) return m.reply('👤 Pengguna tidak sedang di-mute.')
      chat.mutedUsers = chat.mutedUsers.filter(u => u !== user)
      m.reply(`✅ Pengguna @${user.split('@')[0]} telah di-*unmute*.`, null, { mentions: [user] })
      break
  }
}

handler.help = ['mute @user', 'unmute @user']
handler.tags = ['group']
handler.command = /^(mute|unmute)$/i
handler.group = true
handler.admin = true

module.exports = handler