let handler = async (m, { conn, isAdmin }) => {
  if (!m.isGroup) throw 'Fitur ini hanya untuk grup!'
  if (!isAdmin) throw 'Hanya admin yang bisa melihat daftar mute user.'

  let chat = global.db.data.chats[m.chat] || {}
  chat.mutedUsers = chat.mutedUsers || []

  if (!chat.mutedUsers.length) return m.reply('✅ Tidak ada user yang sedang di-*mute* di grup ini.')

  let list = '*👥 Daftar Pengguna yang Di-Mute:*\n\n'
  for (let jid of chat.mutedUsers) {
    let name = await conn.getName(jid).catch(_ => jid.split('@')[0])
    list += `• ${name} @${jid.split('@')[0]}\n`
  }
  m.reply(list.trim(), null, { mentions: chat.mutedUsers })
}

handler.help = ['listmute']
handler.tags = ['group']
handler.command = /^listmute$/i
handler.group = true
handler.admin = true

module.exports = handler