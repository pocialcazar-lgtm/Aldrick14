const fs = require('fs');
const archiver = require('archiver');

let handler = async (m, { conn }) => {
  if (global.conn.user.jid !== conn.user.jid) return;

  conn.sendMessage(m.chat, { react: { text: '🔓', key: m.key } });

  // ⬇️ GANTI NOMOR OWNER DI SINI
  const OWNER_NUMBER = '6283198520706';
  const ownerJid = OWNER_NUMBER.includes('@s.whatsapp.net') ? OWNER_NUMBER : OWNER_NUMBER + '@s.whatsapp.net';

  const fake = {
    key: {
      participant: ownerJid,
      remoteJid: ownerJid
    },
    message: { conversation: '📦 Backup Script' }
  };

  // Nama file = nama bot
  const botName = conn.user.name?.replace(/\s+/g, '_') || 'Bot';
  const zipName = `${botName}_backup.zip`;

  const output = fs.createWriteStream(zipName);
  const archive = archiver('zip', { zlib: { level: 9 } });

  output.on('close', async () => {
    const sizeBytes = archive.pointer();
    const sizeMB = (sizeBytes / 1024 / 1024).toFixed(2);
    const cap = `✅ Backup selesai untuk *${conn.user.name}*\nUkuran: ${sizeMB} MB`;

    try {
      if (sizeBytes > 64 * 1024 * 1024) {
        await m.reply(`❌ Gagal kirim: file terlalu besar (${sizeMB} MB).`);
        return;
      }

      await conn.sendMessage(ownerJid, {
        document: fs.readFileSync(zipName),
        mimetype: 'application/zip',
        fileName: zipName,
        caption: cap
      }, { quoted: fake });

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
      console.error('[ERROR] Kirim gagal:', e);
      await m.reply('❌ Gagal mengirim backup ke owner.');
    }

    try {
      fs.unlinkSync(zipName);
    } catch (err) {
      console.warn('[BACKUP] Gagal hapus file:', err.message);
    }
  });

  archive.on('warning', err => {
    if (err.code !== 'ENOENT') throw err;
  });

  archive.on('error', err => {
    throw err;
  });

  archive.pipe(output);
  archive.glob('**/*', {
    ignore: ['node_modules/**', zipName]
  });

  await archive.finalize();
};

handler.help = ['backup'];
handler.tags = ['owner'];
handler.command = /^backup$/i;
handler.rowner = true;

module.exports = handler;