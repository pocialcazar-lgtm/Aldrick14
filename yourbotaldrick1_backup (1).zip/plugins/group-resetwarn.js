let handler = async (m, { conn, participants, isAdmin, isOwner }) => {
  if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup.'
  if (!isAdmin && !isOwner) throw 'Kamu harus admin atau owner bot.'

  for (let user of participants) {
    if (global.db.data.users[user.id]) {
      global.db.data.users[user.id].warn = 0
    }
  }

  m.reply('✅ Semua peringatan di grup ini telah direset.')
}

handler.help = ['resetwarn']
handler.tags = ['group']
handler.command = /^resetwarn$/i
handler.group = true
handler.admin = true

module.exports = handler