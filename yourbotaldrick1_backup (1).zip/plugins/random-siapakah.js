let handler = async (m, { conn, text, participants }) => {
    if (!m.isGroup) return m.reply('❗Fitur ini hanya bisa digunakan di grup.')

    if (!text) return m.reply('❓ Mau tanya "Siapakah..." apa?\n\nContoh:\n.siapakah yang paling galak?')

    // Ambil semua member grup selain bot
    let member = participants.filter(p => p.id !== conn.user.jid)
    if (member.length === 0) return m.reply('Tidak ada anggota lain untuk dipilih.')

    // Pilih satu orang secara acak
    let randomUser = member[Math.floor(Math.random() * member.length)]
    let mentionId = randomUser.id

    // Format jawaban
    let caption = `🤔 *Siapakah ${text}*\n\n🗯️ Jawabannya adalah...\n👉 @${mentionId.split('@')[0]}!`

    // Kirim pesan dengan mention
    conn.sendMessage(m.chat, {
        text: caption,
        mentions: [mentionId]
    }, { quoted: m })
}

handler.help = ['siapakah <pertanyaan>']
handler.tags = ['random']
handler.command = /^\.?siapakah$/i
handler.group = true

module.exports = handler