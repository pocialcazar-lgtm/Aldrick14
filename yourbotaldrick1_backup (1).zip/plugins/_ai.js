let axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*Example:* ${usedPrefix + command} hai`;

    conn.btch = conn.btch || {};
    if (!conn.btch[m.sender]) {
        conn.btch[m.sender] = { pesan: [] };
    }
    clearTimeout(conn.btch[m.sender].timeout);
    conn.btch[m.sender].timeout = setTimeout(() => {
        delete conn.btch[m.sender];
    }, 300000);

    const previousMessages = conn.btch[m.sender].pesan;

    const messages = [
        { role: "system", content: "Kamu adalah Valena, Asisten pribadi yang dibuat oleh LuccaneXz. Tugasmu adalah menjawab dengan singkat, informatif, dan sopan." },
        { role: "assistant", content: `Saya Valena-Ai, siap membantu kamu kapan pun!` },
        ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
        { role: "user", content: text }
    ];

    try {
        const chat = async (message) => {
            const params = {
                message,
                apikey: btc
            };
            const { data } = await axios.post('https://api.botcahx.eu.org/api/search/openai-custom', params);
            return data;
        };

        let res = await chat(messages);

        if (res && res.result) {
            await m.reply(res.result);
            conn.btch[m.sender].pesan.push(text, res.result);
        } else {
            throw "❌ Tidak ada hasil dari API.";
        }
    } catch (e) {
        throw `❌ Terjadi kesalahan:\n${e.message || e}`;
    }
};

handler.command = handler.help = ['ai'];
handler.tags = ['ai'];
handler.premium = false;
handler.limit = true;

module.exports = handler;