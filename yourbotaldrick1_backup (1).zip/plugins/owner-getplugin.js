const fs = require('fs')
const path = require('path')

let handler = async (m, { usedPrefix, command, text }) => {
  if (!text) throw `🚫 Mana nama plugin-nya?\n\nContoh: ${usedPrefix + command} menu`

  const pluginName = text.replace(/\.js$/i, '')
  const filename = path.join(__dirname, `./${pluginName}.js`)
  const listPlugins = fs.readdirSync(__dirname).map(v => v.replace(/\.js$/, ''))

  if (!fs.existsSync(filename)) {
    return m.reply(`❌ Plugin '${pluginName}' tidak ditemukan!\n\n🔎 Berikut list plugin:\n${listPlugins.join('\n')}`)
  }

  try {
    const fileContent = fs.readFileSync(filename, 'utf8')

    const watermark = `/*
 * 📦 Plugin: ${pluginName}.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/`

    const output = `${watermark}\n\n${fileContent}`
    m.reply(output)
  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal membaca file plugin.')
  }
}

handler.help = ['getplugin [filename]']
handler.tags = ['owner']
handler.command = /^(getplugin|get ?plugin|gp)$/i
handler.rowner = true

module.exports = handler