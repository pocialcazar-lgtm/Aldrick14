let handler = async (m, { conn, text, isROwner, isOwner }) => {
  if (!m.isGroup) throw '❌ Fitur ini hanya dapat digunakan di dalam grup.'

  if (!text) {
    throw `Kirim perintah dengan format:\n\n.setwelcome <teks>\n\nKeterangan:\n@user → Mention member baru\n@subject → Nama grup\n@desc → Deskripsi grup\n\nContoh:\n.setwelcome Selamat datang @user di grup @subject!\nJangan lupa baca deskripsi: @desc`
  }

  // Simpan pesan welcome
  const chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}

  if (isROwner) global.conn.welcome = text
  else if (isOwner) conn.welcome = text

  chat.sWelcome = text

  m.reply(`✅ Pesan welcome berhasil diatur!\n\nGunakan format:\n@user → Mention member\n@subject → Nama grup\n@desc → Deskripsi grup`)
}

handler.help = ['setwelcome <teks>']
handler.tags = ['owner', 'group']
handler.command = /^setwelcome$/i
handler.botAdmin = true
handler.group = true
handler.admin = true // hanya admin grup yang bisa set welcome

module.exports = handler