const { createHash } = require('crypto')

let handler = async function (m, { conn }) {
  let user = global.db.data.users[m.sender]
  if (!user.registered) throw '❌ Kamu belum terdaftar.\n\nKetik *.daftar* untuk mulai mendaftar.'

  let sn = createHash('md5').update(m.sender).digest('hex')

  user.registered = false
  user.name = ''
  user.age = 0
  user.gender = ''
  user.regTime = 0

  m.reply(`
╭───〈 *UNREGISTER BERHASIL* 〉───
│✅ Data pendaftaran kamu telah dihapus.
│📎 *Nomor Seri (SN)*:
│${sn}
│
│Untuk mendaftar ulang:
│📌 Gunakan perintah: *.daftar nama.umur.gender*
╰───────────────
`.trim())
}

handler.help = ['unreg']
handler.tags = ['info']
handler.command = /^unreg$/i
handler.register = true

module.exports = handler