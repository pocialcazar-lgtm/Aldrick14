/*
 * 📦 Plugin: dl-pinterest.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

let fetch = require('node-fetch');

let handler = async (m, { usedPrefix, command, conn, text }) => {
  if (!text) throw `*🚩 Contoh:* ${usedPrefix}${command} Zhao Lusi`;
  m.reply(wait)

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/pinterest?text1=${encodeURIComponent(text)}&apikey=${btc}`);
    const json = await res.json();

    if (!json.status || !json.result || json.result.length === 0) throw '❌ Gambar tidak ditemukan';

    let old = new Date();
    let hasil = json.result[Math.floor(Math.random() * json.result.length)]; // ambil satu gambar random

    await conn.sendMessage(m.chat, {
      image: { url: hasil },
      caption: `✅ *Pinterest Result*\n🔎 Keyword: *${text}*\n⏱️ Speed: *${new Date() - old} ms*`,
      contextInfo: {
        externalAdReply: {
          title: 'Hasil Pencarian Pinterest',
          body: 'Klik untuk cari lebih banyak',
          thumbnailUrl: hasil,
          sourceUrl: `https://id.pinterest.com/search/pins/?q=${encodeURIComponent(text)}`
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    throw '❌ Gagal mengambil data Pinterest.'
  }
};

handler.help = ['pinterest <keyword>'];
handler.tags = ['search'];
handler.command = /^(pinterest|pin)$/i;

module.exports = handler;