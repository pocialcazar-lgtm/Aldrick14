let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  if (!user.ultah) throw 'Kamu belum mengatur tanggal ulang tahun.'

  delete user.ultah
  m.reply('✅ Tanggal ulang tahun kamu telah dihapus.')
}

handler.help = ['delultahku']
handler.tags = ['group']
handler.command = /^delultahku$/i

module.exports = handler