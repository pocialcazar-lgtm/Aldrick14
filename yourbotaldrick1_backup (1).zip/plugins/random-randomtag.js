let handler = async (m, { conn, participants }) => {
    if (!m.isGroup) return m.reply('❗Fitur ini hanya untuk grup.')

    // Filter semua peserta kecuali bot
    let members = participants.filter(p => p.id !== conn.user.jid)
    if (!members.length) return m.reply('Tidak ada anggota yang bisa dipilih.')

    // Pilih satu member acak
    let randomUser = members[Math.floor(Math.random() * members.length)]

    // Kirim mention
    let text = `🎯 Tag random untuk: @${randomUser.id.split('@')[0]}`
    conn.sendMessage(m.chat, {
        text,
        mentions: [randomUser.id]
    }, { quoted: m })
}

handler.help = ['randomtag']
handler.tags = ['random']
handler.command = /^\.?randomtag$/i
handler.group = true

module.exports = handler