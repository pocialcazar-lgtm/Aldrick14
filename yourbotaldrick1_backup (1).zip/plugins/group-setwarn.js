let handler = async (m, { conn, args, isAdmin, isOwner, isBotAdmin }) => {
  if (!m.isGroup) throw 'Fitur ini hanya dapat digunakan di grup!'
  if (!isAdmin && !isOwner) throw 'Kamu harus admin grup atau owner bot!'
  if (!isBotAdmin) throw 'Bot harus admin untuk mengatur limit warn!'

  let jumlah = parseInt(args[0])
  if (isNaN(jumlah) || jumlah < 1) throw 'Contoh penggunaan: .setwarn 3 (minimal 1)'

  global.db.data.chats[m.chat].maxwarn = jumlah
  m.reply(`✅ Jumlah maksimal *warn* di grup ini telah diubah menjadi *${jumlah}* peringatan.`)
}

handler.help = ['setwarn <angka>']
handler.tags = ['group']
handler.command = /^setwarn$/i
handler.admin = true
handler.group = true

module.exports = handler