let handler = async (m, { conn }) => {
  try {
    const participants = (await conn.groupMetadata(m.chat)).participants
    const onlineList = []

    for (const p of participants) {
      try {
        await conn.presenceSubscribe(p.id)
        await new Promise(resolve => setTimeout(resolve, 100)) // jeda biar tidak rate limit
        const presence = conn.presence[p.id]
        if (presence && presence.lastKnownPresence === 'available') {
          onlineList.push(p.id)
        }
      } catch (e) {
        // Abaikan error per user
      }
    }

    if (!onlineList.length) {
      return m.reply('❌ Tidak ada member yang online saat ini.')
    }

    let teks = '┌─〔 Daftar Online 〕\n'
    teks += onlineList.map(v => '├ @' + v.split('@')[0]).join('\n')
    teks += '\n└────'

    await conn.reply(m.chat, teks, m, {
      contextInfo: {
        mentionedJid: onlineList
      }
    })

  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengambil daftar online.')
  }
}

handler.help = ['listonline']
handler.tags = ['group']
handler.command = /^liston(line)?$/i

handler.group = true
handler.botAdmin = true // wajib admin untuk akses presence
handler.limit = false

module.exports = handler