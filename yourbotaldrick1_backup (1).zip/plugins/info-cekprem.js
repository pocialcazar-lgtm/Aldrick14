let handler = async (m, { conn, text }) => {
  let user = db.data.users[m.sender]
  let isPrem = user.premium
  let expired = user.premiumTime

  if (isPrem) {
    let until = new Date(expired).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
    m.reply(`💎 *Status PREMIUM*\n\n✅ Kamu adalah pengguna premium!\n🗓️ Berlaku hingga: *${until}*`)
  } else {
    m.reply(`🚫 *Status PREMIUM*\n\n❌ Kamu *bukan* pengguna premium.\n🔑 Coba beli premium untuk menikmati semua fitur.`)
  }
}

handler.help = ['cekprem']
handler.tags = ['info']
handler.command = /^cekprem$/i
handler.register = false

module.exports = handler