const fetch = require('node-fetch')

let timeout = 120000
let poin = 10000

let handler = async (m, { conn }) => {
  conn.tebakgambar = conn.tebakgambar || {}
  let id = m.chat

  if (id in conn.tebakgambar) {
    return m.reply('❌ Masih ada soal yang belum dijawab!')
  }

  let res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
  let json = await res.json()
  let random = json[Math.floor(Math.random() * json.length)]
  let jawaban = random.jawaban.toLowerCase().trim()
  let panjang = jawaban.length

  let caption = `🧠 *TEBAK GAMBAR!*\n\n` +
                `📷 Jawaban berdasarkan gambar di bawah.\n` +
                `⌛ Waktu: ${(timeout / 1000)} detik\n` +
                `📌 Clue: *${panjang} huruf*\n` +
                `❓ Ketik *.hint* jika butuh bantuan.`

  conn.tebakgambar[id] = [
    await conn.sendMessage(m.chat, {
      image: { url: random.img },
      caption
    }, { quoted: m }),
    random,
    poin,
    setTimeout(() => {
      if (conn.tebakgambar[id]) {
        conn.sendMessage(m.chat, {
          text: `⏱️ *Waktu habis!*\nJawabannya adalah: *${jawaban}*`
        })
        delete conn.tebakgambar[id]
      }
    }, timeout)
  ]
}

handler.help = ['tebakgambar']
handler.tags = ['game']
handler.command = /^tebakgambar$/i

module.exports = handler