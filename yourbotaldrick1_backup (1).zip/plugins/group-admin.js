let handler = async (m, { conn, participants, groupMetadata }) => {
    if (!m.isGroup) return conn.reply(m.chat, '❗Fitur ini hanya untuk grup.', m)

    const getGroupAdmins = (participants) => {
        let admins = []
        for (let i of participants) {
            if (i.admin) admins.push(i.id)
        }
        return admins
    }

    const groupAdmins = getGroupAdmins(participants || [])
    if (!groupAdmins.length) return conn.reply(m.chat, 'Tidak ada admin terdeteksi di grup ini.', m)

    let listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.split('@')[0]}`).join('\n')
    let groupOwner = groupMetadata?.owner || m.chat.split`-`[0] + "@s.whatsapp.net"

    let text = `*「 TAG ADMIN 」*

*📛 Nama Grup:* 
${groupMetadata?.subject || 'Tidak diketahui'}

*👑 Pemilik Grup:* 
@${groupOwner.split('@')[0]}

*🛡️ Admin Grup:*
${listAdmin}
`.trim()

    let mentionedJid = groupAdmins.concat(groupOwner)

    await conn.sendMessage(m.chat, {
        text,
        mentions: mentionedJid
    }, { quoted: m })
}

handler.help = ['admin']
handler.tags = ['group']
handler.command = /^\.?admin$/i
handler.group = true

module.exports = handler