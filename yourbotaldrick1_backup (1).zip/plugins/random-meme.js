let fetch = require('node-fetch')
let handler = async (m, { conn, text }) => {
  try { 
    let res = await fetch(`https://api.botcahx.eu.org/api/random/meme?apikey=${btc}`)
    if (!res.ok) throw `❌ Gagal mengambil meme. Coba lagi nanti.`

    let img = await res.buffer()
    await conn.sendFile(m.chat, img, 'meme.jpg', wm, m)
  } catch (e) {
    throw `❌ Terjadi kesalahan:\n${e.message || e}`
  }
}

handler.command = /^(meme)$/i
handler.tags = ['random']
handler.help = ['meme']
handler.limit = true
module.exports = handler