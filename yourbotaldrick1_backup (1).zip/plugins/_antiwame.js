module.exports = {
  async before(m, { conn }) {
    if (!m.isGroup) return
    if (m.fromMe) return
    if (!m.text) return

    const chat = global.db.data.chats[m.chat]
    const isWame = /(https?:\/\/)?wa\.me\/\d{9,}/i.test(m.text)

    if (chat.antiwamekick && isWame) {
      if (!m.isAdmin && !m.key.fromMe && conn.user.jid !== m.sender) {
        await m.reply('⛔ *Link WhatsApp terdeteksi!*\nKamu akan dikeluarkan dari grup.')
        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
      }
    } else if (chat.antiwamenokick && isWame) {
      if (!m.isAdmin && !m.key.fromMe) {
        await m.reply('🚫 *Link WhatsApp tidak diizinkan!* Pesan kamu telah dihapus.')
        return m.delete()
      }
    }
  }
}