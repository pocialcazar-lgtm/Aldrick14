const axios = require('axios');
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';

  if (!mime) throw `⚠️ Balas gambar dengan perintah *${usedPrefix + command}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw '⚠️ Format tidak didukung. Hanya menerima gambar JPG atau PNG.';
  
  let media = await q.download();
  if (!media || media.length > 2 * 1024 * 1024) throw '⚠️ Gambar harus kurang dari 2MB.';

  m.reply('⏳ Sedang membuat stiker trigger...');

  try {
    // Simpan ke file temporer
    const tmpPath = path.join(__dirname, '../tmp', `${+new Date()}.jpg`);
    fs.writeFileSync(tmpPath, media);

    // Kirim ke API
    const form = new FormData();
    form.append('file', fs.createReadStream(tmpPath));

    const response = await axios.post(
      `https://api.botcahx.eu.org/api/tools/trigger?apikey=${btc}`,
      form,
      { headers: form.getHeaders(), responseType: 'arraybuffer' }
    );

    fs.unlinkSync(tmpPath); // hapus file temporer

    // Kirim sebagai stiker
    await conn.sendImageAsSticker(m.chat, response.data, m, {
      packname: global.packname,
      author: global.author
    });

  } catch (e) {
    console.log(e);
    throw `⚠️ Gagal membuat stiker trigger.

• Pastikan:
- API aktif dan valid
- Gambar < 2MB
- Kirim gambar biasa, bukan stiker/webp`;
  }
};

handler.help = ['trigger'];
handler.tags = ['sticker'];
handler.command = /^trigger$/i;
handler.limit = true;
module.exports = handler;