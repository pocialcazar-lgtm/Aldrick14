const fetch = require('node-fetch')

const handler = async (m, { conn, text, command }) => {
  if (!text) throw `Contoh: .${command} kucing lucu pakai kacamata hitam`

  let prompt = encodeURIComponent(text)
  let url = `https://image.pollinations.ai/prompt/${prompt}`

  try {
    await conn.sendMessage(m.chat, {
      image: { url: url },
      caption: `🎨 Prompt: ${text}`
    }, { quoted: m })
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengambil gambar dari API (kemungkinan prompt tidak dipahami atau API sedang down)')
  }
}

handler.command = /^bingimg$/i
handler.tags = ['ai']
handler.help = ['bingimg <prompt>']
handler.register = false
handler.limit = false

module.exports = handler