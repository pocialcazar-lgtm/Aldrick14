module.exports = {
  name: 'antilinknokick',
  async before(m, { conn, isAdmin, isOwner }) {
    if (!m.isGroup) return
    const chat = global.db.data.chats[m.chat]
    if (!chat.antilinknokick) return
    const regex = /https?:\/\/[^\s]+/gi
    if (regex.test(m.text) && !isAdmin && !isOwner) {
      await conn.sendMessage(m.chat, {
        delete: m.key
      })
    }
  }
}