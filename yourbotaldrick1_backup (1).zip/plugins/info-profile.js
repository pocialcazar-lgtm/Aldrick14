/*
 * 📦 Plugin: info-profile.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

let PhoneNumber = require('awesome-phonenumber')
let levelling = require('../lib/levelling')

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender]

  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  let who
  if (m.mentionedJid?.[0]) who = m.mentionedJid[0]
  else if (m.quoted) who = m.quoted.sender
  else if (text) {
    text = no(text)
    who = isNaN(text) ? text.split`@`[1] + '@s.whatsapp.net' : text + '@s.whatsapp.net'
  } else who = m.sender

  if (who.length > 30) return conn.reply(m.chat, '❌ Nomor tidak valid!', m)
  if (!global.db.data.users[who]) return conn.reply(m.chat, '❌ Pengguna tidak ditemukan di database.', m)

  let target = global.db.data.users[who]
  let {
    name, limit, exp, money, registered, regTime, premium
  } = target

  let username = await conn.getName(who)
  let about = (await conn.fetchStatus(who).catch(() => ({})))?.status || '-'
  let number = PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')
  let joinDate = registered ? new Date(regTime).toLocaleDateString('id') : 'Belum terdaftar'
  let status = premium ? 'Premium' : 'Free'

  let pp = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXIdvC1Q4WL7_zA6cJm3yileyBT2OsWhBb9Q&usqp=CAU'
  try { pp = await conn.profilePictureUrl(who, 'image') } catch {}

  let str = `
╭────✎「 *Profile User* 」
│• Name: ${registered ? name : username}
│• Tag: @${who.split('@')[0]}
│• Api: ${number ? `wa.me/${who.split('@')[0]}` : '-'}
│• Status: ${status}
│• Limit: ${limit}/50
│• Balance: Rp${money.toLocaleString()}
│• Member since: ${joinDate}
╰─────────❍
`.trim()

  conn.sendFile(m.chat, pp, 'profile.jpg', str, m, {
    contextInfo: {
      mentionedJid: [who]
    }
  })
}

handler.help = ['profile [@user|nomor]']
handler.tags = ['info']
handler.command = /^(profile|me)$/i // ✅ Sudah diperbaiki
handler.limit = true
handler.register = false
handler.group = true

module.exports = handler