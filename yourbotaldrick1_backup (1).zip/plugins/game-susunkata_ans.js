const similarity = require('similarity')
const threshold = 0.72
const poin = 10000

let handler = m => m

handler.before = async function (m) {
    let id = m.chat
    this.susun = this.susun || {}

    if (!(id in this.susun)) return // ⛔ Tidak ada soal aktif? keluar saja

    let [pesanSoal, json, poinBonus, timeout] = this.susun[id]

    // ✅ Jika user tidak reply atau reply ke pesan selain soal, tolak
    if (!m.quoted || m.quoted.id !== pesanSoal.key.id) return

    let jawabanUser = m.text.toLowerCase().trim()
    let jawabanBenar = json.jawaban.toLowerCase().trim()

    if (jawabanUser === jawabanBenar) {
        let user = global.db.data.users[m.sender]
        user.exp += poinBonus
        user.money += poin
        m.reply(`✅ *Benar!*\n+${poin} money\n+${poinBonus} XP`)
        clearTimeout(timeout)
        delete this.susun[id]
    } else if (similarity(jawabanUser, jawabanBenar) >= threshold) {
        m.reply('⚠️ *Dikit lagi!*')
    } else {
        m.reply('❌ *Salah!*')
    }

    return !0
}

handler.exp = 0
module.exports = handler