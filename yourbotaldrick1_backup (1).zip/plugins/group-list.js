const moment = require('moment-timezone');

let handler = async (m, { conn, noPrefix, command, groupMetadata }) => {
	let msgs = db.data.chats[m.chat].listStr;
	let msg = Object.entries(db.data.chats[m.chat].listStr)
		.map(([nama, isi]) => ({ nama, ...isi }))
		.map(v => v.nama);
	let name = msg.sort();
	let ucapanni = ucapan();
	let wibh = moment.tz('Asia/Jakarta').format('HH');
	let wibm = moment.tz('Asia/Jakarta').format('mm');
	let wktuwib = `_Jam ${wibh} : ${wibm} Menit_`;
	let teks = name.map(v => `○ ${v.toUpperCase()}`).filter(v => v).join('\n');
	let cap = `${ucapanni} @${m.sender.split`@`[0]}\nDi bawah ini adalah Daftar List\n*${groupMetadata.subject}*\n\nUntuk melihat List\nKetik *Tulisan* di bawah ini\n*——————— Daftar List ———————*\n\n${teks}\n`;

	if (msg[0]) {
		return await conn.sendMessage(m.chat, {
			text: cap,
			contextInfo: {
				mentionedJid: [m.sender],
			}
		});
	} else {
		throw `\nBelum Ada List Yang Ditambahkan Admin\nketik *.addlist <text>* untuk menambahkan daftar menu.\n\nJika kamu ingin melihat allfitur tulis *.allmenu*`;
	}
};

handler.help = ['list'];
handler.tags = ['group'];
handler.customPrefix = /^(menu|list)$/i;
handler.command = new RegExp;
handler.group = true;

module.exports = handler;

function ucapan() {
	const hour_now = moment.tz('Asia/Jakarta').format('HH');
	let ucapanWaktu = '🌅 Pagi';
	if (hour_now >= '03' && hour_now <= '10') {
		ucapanWaktu = '🌅 Pagi';
	} else if (hour_now > '10' && hour_now <= '15') {
		ucapanWaktu = '☀️ Siang';
	} else if (hour_now > '15' && hour_now <= '18') {
		ucapanWaktu = '🌇 Sore';
	} else if (hour_now > '18' && hour_now <= '23') {
		ucapanWaktu = '🌃 Malam';
	} else {
		ucapanWaktu = '🌃 Malam';
	}
	return ucapanWaktu;
}