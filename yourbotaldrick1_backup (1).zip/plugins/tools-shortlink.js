const axios = require('axios')

let handler = async (m, { args, text, usedPrefix, command }) => {
  if (!text) return m.reply(`📌 Contoh:\n${usedPrefix + command} https://example.com`)

  if (!/^https?:\/\//i.test(text)) return m.reply('❗ Masukkan URL yang valid.')

  try {
    let { data } = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(text)}`)
    
    if (!data || data.includes('Error')) throw 'Gagal membuat shortlink.'

    m.reply(`🔗 *Shortlink Berhasil!*\n\n📍 Asli: ${text}\n➡️ Short: ${data}`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal membuat shortlink. Pastikan URL valid dan coba lagi.')
  }
}

handler.help = ['shortlink <url>']
handler.tags = ['tools']
handler.command = /^short(link)?$/i

module.exports = handler