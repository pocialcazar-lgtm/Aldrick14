const { MessageType } = require('@adiwajshing/baileys').default;

let handler = async (m, { conn, text, usedPrefix, command }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
  }

  if (!text || !text.includes('|')) {
    return conn.reply(m.chat, `❌ *FORMAT SALAH!*\n\n📌 Gunakan format:\n${usedPrefix + command} @tag/nomor|jumlahHari\n\n*Contoh:* ${usedPrefix + command} 6285764068784|30\n*Contoh permanen:* ${usedPrefix + command} 6285764068784|permanent`, m);
  }

  let [target, days] = text.split('|');
  target = no(target) + '@s.whatsapp.net';

  if (!db.data.users[target]) throw '⚠️ Pengguna belum ada dalam database!';

  let now = Date.now();
  let isPermanent = days.toLowerCase() === 'permanent';
  let ms = 86400000 * parseInt(days);

  db.data.users[target].premium = true;
  db.data.users[target].premiumTime = isPermanent ? Infinity : (db.data.users[target].premiumTime > now ? db.data.users[target].premiumTime + ms : now + ms);

  let premiumUntil = isPermanent 
    ? '♾️ PERMANENT'
    : new Date(db.data.users[target].premiumTime).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

  // Balasan ke pengirim
  conn.reply(m.chat, `
🎉 *PREMIUM SUKSES!*

👤 Pengguna: @${target.split('@')[0]}
⏳ Durasi: *${isPermanent ? 'Permanent' : `${days} hari`}*
📅 Berlaku sampai: *${premiumUntil}*

✅ Akses premium telah ditambahkan!
  `.trim(), m, { contextInfo: { mentionedJid: [target] } });

  // Balasan ke target user
  conn.reply(target, `
✨ *SELAMAT!*
Kamu telah mendapatkan akses *PREMIUM* ${isPermanent ? 'secara *PERMANEN*' : `selama *${days} hari*`} 🎊

🗓️ Berlaku sampai: *${premiumUntil}*
📌 Nikmati semua fitur spesial dari bot ini!

Terima kasih telah menggunakan layanan kami. 💎
  `.trim(), m);
};

handler.help = ['addprem *@tag|hari/permanent*'];
handler.tags = ['owner'];
handler.command = /^(addprem|prem)$/i;
handler.owner = true;
handler.fail = null;

module.exports = handler;