const { MessageType } = require('@adiwajshing/baileys').default

let handler = async (m, { conn, text, usedPrefix, command }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  if (!text) {
    return conn.reply(m.chat, `❌ *FORMAT SALAH!*\n\n📌 Gunakan format:\n${usedPrefix + command} @tag/nomor`, m)
  }

  let target = no(text) + '@s.whatsapp.net'

  if (!db.data.users[target]) throw '⚠️ Pengguna belum ada dalam database!'

  db.data.users[target].premium = false
  db.data.users[target].premiumTime = 0

  conn.reply(m.chat, `✅ Premium untuk @${target.split('@')[0]} telah *dihapus*!`, m, { contextInfo: { mentionedJid: [target] } })
}

handler.help = ['delprem *@tag/nomor*']
handler.tags = ['owner']
handler.command = /^(delprem|hapusprem)$/i
handler.owner = true
handler.fail = null

module.exports = handler