let handler = async (m, { text }) => {
    if (!text) return m.reply('❓ Apa yang ingin kamu nilai?\n\nContoh:\n.rate seberapa ganteng aku')

    let rate = Math.floor(Math.random() * 100) + 1 // nilai 1–100
    let caption = `📊 *${text}*\n\nHmmm🤔... *${rate}%* 😁`

    m.reply(caption)
}

handler.help = ['rate <pertanyaan>']
handler.tags = ['random']
handler.command = /^\.?rate$/i

module.exports = handler