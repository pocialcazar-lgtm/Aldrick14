let handler = async (m, { conn, participants }) => {
    if (!m.isGroup) return m.reply('❗Fitur ini hanya bisa digunakan di grup.')

    // Ambil semua member grup selain bot
    let member = participants.filter(p => p.id !== conn.user.jid)

    // Acak pasangan
    let orang1 = member[Math.floor(Math.random() * member.length)]
    let orang2 = member[Math.floor(Math.random() * member.length)]

    // Kalau sama orangnya, ulang sampai beda
    while (orang1.id === orang2.id) {
        orang2 = member[Math.floor(Math.random() * member.length)]
    }

    // Pesan hasil jadian
    let caption = `💞 *Ciee yang jadian...* 💞

@${orang1.id.split('@')[0]} ❤️ @${orang2.id.split('@')[0]}

Semoga langgeng yaa! 🥰
`.trim()

    // Mention keduanya
    conn.sendMessage(m.chat, {
        text: caption,
        mentions: [orang1.id, orang2.id]
    }, { quoted: m })
}

handler.help = ['jadian']
handler.tags = ['random']
handler.command = /^\.?jadian$/i
handler.group = true

module.exports = handler