let handler = async (m, { conn, isOwner, isAdmin, participants, command }) => {
  if (m.isBaileys) return;

  if (!(isAdmin || isOwner)) {
    global.dfail('admin', m, conn);
    throw false;
  }

  const ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";
  let users = [];

  // Deteksi target user
  if (m.quoted) {
    users = [m.quoted.sender];
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    users = m.mentionedJid;
  } else {
    return m.reply('Tag atau reply user yang ingin dijadikan admin.');
  }

  // Filter agar tidak promote owner atau bot sendiri
  users = users.filter(user =>
    user.endsWith('@s.whatsapp.net') &&
    user !== ownerGroup &&
    user !== conn.user.jid
  );

  if (users.length === 0) {
    return m.reply('Tidak ada user valid untuk dipromosikan.');
  }

  // Cek apakah bot adalah admin
  const bot = participants.find(u => u.id === conn.user.jid);
  if (!bot?.admin) {
    return m.reply('Bot harus menjadi admin untuk menjalankan perintah ini!');
  }

  for (let user of users) {
    try {
      await conn.groupParticipantsUpdate(m.chat, [user], "promote");
      await conn.sendMessage(m.chat, { text: `✅ Berhasil promote @${user.split('@')[0]}`, mentions: [user] });
    } catch (e) {
      console.error(`Gagal promote ${user}:`, e);
      await conn.sendMessage(m.chat, { text: `❌ Gagal promote @${user.split('@')[0]}`, mentions: [user] });
    }
  }
};

handler.help = ['promote @user'];
handler.tags = ['group'];
handler.command = /^(promote|admin|\^)$/i;

handler.group = true;
handler.botAdmin = true;
handler.admin = true;

module.exports = handler;