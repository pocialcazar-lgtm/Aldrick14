// 📦 Plugin: fun-faktaunik.js
// 🔖 LuccaneXz Official

let handler = async (m, { conn }) => {
  const fakta = [
    "🧠 Otak manusia lebih aktif saat tidur daripada saat bangun.",
    "🐙 Gurita memiliki tiga hati dan darah berwarna biru.",
    "💧 Air panas membeku lebih cepat daripada air dingin — fenomena ini disebut efek Mpemba.",
    "🐘 Gajah adalah satu-satunya hewan yang tidak bisa melompat.",
    "🦋 Kupu-kupu bisa merasakan rasa dengan kakinya.",
    "🌍 Sekitar 70% permukaan Bumi tertutup oleh air.",
    "🧊 Es di Antartika menyimpan sekitar 90% air tawar dunia.",
    "🦎 Beberapa spesies kadal bisa memotong ekornya untuk menghindari pemangsa.",
    "🌕 Di Bulan, jejak kaki astronot bisa bertahan jutaan tahun karena tidak ada angin.",
    "🧬 DNA manusia 60% mirip dengan DNA pisang.",
    "💡 Thomas Edison bukan penemu pertama bola lampu, tapi dia yang menyempurnakannya.",
    "📱 Lebih banyak orang di dunia memiliki ponsel daripada toilet.",
    "🐢 Penyu bisa tidur hingga 10 jam di bawah air.",
    "🚀 Jika kamu terbang keluar angkasa, kamu akan tumbuh sedikit lebih tinggi.",
    "🍫 Coklat bisa mematikan bagi anjing karena mengandung theobromine.",
    "🐼 Panda menghabiskan 12 jam sehari hanya untuk makan bambu.",
    "😴 Kita menghabiskan sekitar sepertiga hidup kita untuk tidur.",
    "📚 Otak manusia bisa menyimpan informasi hingga 2,5 petabyte — setara dengan 3 juta jam video!",
    "🍌 Pisang termasuk dalam keluarga beri (berry), tapi stroberi tidak.",
    "🧊 Kutub utara sebenarnya adalah lautan yang tertutup es, bukan daratan."
  ];

  const result = fakta[Math.floor(Math.random() * fakta.length)];
  conn.sendMessage(m.chat, { text: result }, { quoted: m });
};

handler.command = /^(faktaunik)$/i;
handler.tags = ['random'];
handler.help = ['faktaunik'];
handler.limit = true;

module.exports = handler;