let handler = async (m, { conn, args, isAdmin, isOwner }) => {
  if (!m.isGroup) throw 'Fitur hanya untuk grup'
  if (!isAdmin && !isOwner) throw 'Hanya admin yang bisa menambahkan kata'

  let word = args.join(' ').toLowerCase()
  if (!word) throw 'Masukkan kata yang ingin ditambahkan ke daftar kata kasar'

  let chat = global.db.data.chats[m.chat]
  chat.badwords = chat.badwords || []

  if (chat.badwords.includes(word)) throw 'Kata tersebut sudah ada dalam daftar'

  chat.badwords.push(word)
  m.reply(`✅ Berhasil menambahkan kata: *${word}* ke daftar kata kasar`)
}

handler.help = ['addbadword <kata>']
handler.tags = ['group']
handler.command = /^addbadword$/i
handler.admin = true
handler.group = true

module.exports = handler