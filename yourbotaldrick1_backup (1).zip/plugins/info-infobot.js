let handler = async (m, { conn }) => {
  const info = `
╭─〔 🤖 *INFO BOT* 〕
│📛 Nama Bot : Aldrick Bot
│🧑‍💻 Developer : Luccane Offc
│👥 Pengembang : Xz Team Community
│👑 Pemilik Bot : Ketik .owner untuk melihat kontak
│🌐 Prefix : . / ! / #
╰───────

╭─〔 🌐 *SOSIAL MEDIA* 〕
│📢 Channel WhatsApp:
│🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
│👥 Grup Diskusi WhatsApp:
│🔗 https://chat.whatsapp.com/E3jreeomzmi5j3Szz8HeKS
│📸 Instagram:
│🔗 https://instagram.com/4li.rshid
│💬 Github/Xz:
│🔗 -
╰───────

╭─〔 ⚠️ *RULES PENGGUNAAN BOT* 〕
│1. Dilarang spam command
│2. Dilarang call/VC bot
│3. Jangan menyebarkan bug, crash, atau exploit
│4. Gunakan bot dengan bijak dan sopan
│5. Admin berhak memblokir pengguna yang melanggar
╰───────

Terima kasih telah menggunakan Aldrick Bot.
`.trim()

  m.reply(info)
}

handler.help = ['infobot']
handler.tags = ['info']
handler.command = /^infobot$/i
handler.register = false

module.exports = handler