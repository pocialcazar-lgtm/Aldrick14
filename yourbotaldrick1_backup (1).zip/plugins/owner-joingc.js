const { default: axios } = require('axios')

let handler = async (m, { conn }) => {
  if (!m.quoted || !m.quoted.text) return m.reply('❌ Reply pesan yang berisi link undangan grup WhatsApp.')

  let url = m.quoted.text.trim().match(/https:\/\/chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}/i)
  if (!url) return m.reply('❌ Tidak ada link undangan grup yang valid pada pesan yang direply.')

  try {
    const link = url[0].split('/')[3]
    await conn.groupAcceptInvite(link)

    m.reply('✅ Berhasil join ke grup!\n🔗 ' + url[0])
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal join ke grup. Pastikan link masih aktif dan bot belum di-ban.')
  }
}

handler.help = ['joingc']
handler.tags = ['owner']
handler.command = /^joingc$/i
handler.owner = true // Hanya owner yang bisa pakai

module.exports = handler