let handler = async (m, { conn }) => {
    if (!m.isGroup) throw '❌ Perintah ini hanya bisa digunakan di grup!'

    let groupMetadata = await conn.groupMetadata(m.chat)
    let isAdmin = groupMetadata.participants.find(p => p.id === m.sender)?.admin
    if (!isAdmin) throw '❌ Perintah ini hanya bisa digunakan oleh *Admin* grup!'

    let chats = db.data.chats[m.chat] = db.data.chats[m.chat] || {}
    chats.totalchat = {}

    m.reply('✅ Data total pesan berhasil di-reset untuk grup ini.')
}

handler.help = ['resettotalpesan']
handler.tags = ['group']
handler.command = /^resettotalpesan$/i
handler.group = true

module.exports = handler