const moment = require('moment-timezone');

async function handler(m, { conn, text, command }) {
    if (!m.isGroup) throw '❗ Fitur ini hanya bisa digunakan di dalam grup.';

    const chat = db.data.chats[m.chat] = db.data.chats[m.chat] || {};
    chat.blacklist = Array.isArray(chat.blacklist) ? chat.blacklist : [];

    const bl = chat.blacklist;
    const number = text?.replace(/[^0-9]/g, '');
    const who = number ? number + '@s.whatsapp.net' : m.mentionedJid?.[0] || m.quoted?.sender;

    switch (command) {
        case 'blacklist': {
            if (!who) throw 'Contoh: .blacklist 628xxxx alasan atau tag/reply pesan + alasan';
            if (bl.find(v => v.id === who)) throw `⚠️ Nomor @${who.split("@")[0]} sudah ada di *Blacklist*.`;

            const reason = text?.split(/\s+/).slice(1).join(' ') || 'Tidak disebutkan';
            const date = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
            bl.push({ id: who, reason, date });

            await conn.reply(m.chat, `✅ @${who.split("@")[0]} telah ditambahkan ke *Blacklist*.\n📄 *Alasan:* ${reason}`, m, {
                mentions: [who]
            });
            break;
        }

        case 'unblacklist': {
            if (!who) throw 'Contoh: .unblacklist 628xxxx atau reply/tag pesan';
            if (!bl.find(v => v.id === who)) throw `⚠️ Nomor @${who.split("@")[0]} tidak ada dalam *Blacklist*.`;

            chat.blacklist = bl.filter(v => v.id !== who);

            await conn.reply(m.chat, `✅ @${who.split("@")[0]} telah dihapus dari *Blacklist*.`, m, {
                mentions: [who]
            });
            break;
        }

        case 'listblacklist':
        case 'listbl': {
            if (bl.length === 0) throw '📃 Tidak ada nomor dalam blacklist grup ini.';
            let txt = `*「 Daftar Blacklist Grup 」*\n\n*Total:* ${bl.length}\n\n`;
            for (let i = 0; i < bl.length; i++) {
                const item = bl[i];
                txt += `${i + 1}. @${item.id.split("@")[0]}\n   📄 *Alasan:* ${item.reason}\n   🕒 *Tanggal:* ${item.date}\n\n`;
            }

            return conn.reply(m.chat, txt.trim(), m, {
                mentions: bl.map(v => v.id)
            });
        }

        case 'resetblacklist': {
            if (bl.length === 0) throw '📃 Tidak ada data blacklist untuk direset.';
            if (text.trim().toLowerCase() !== 'yes') {
                throw '⚠️ Apakah kamu yakin ingin menghapus seluruh blacklist?\nKetik: *.resetblacklist yes* untuk konfirmasi.';
            }

            chat.blacklist = [];

            await conn.reply(m.chat, '✅ Seluruh data *Blacklist* telah dihapus.', m);
            break;
        }
    }
}

handler.before = async function (m, { conn, isBotAdmin }) {
    if (!m.isGroup || !isBotAdmin) return;

    const chatId = m.chat;
    const sender = m.sender;
    const bl = db.data.chats[chatId]?.blacklist || [];

    // Kick jika user kirim pesan dan ada di blacklist
    const userFromMessage = bl.find(v => v.id === sender);
    if (userFromMessage) {
        await conn.reply(chatId, `🚫 @${sender.split("@")[0]} dikick karena *masuk Blacklist* dan mengirim pesan.\n📄 *Alasan:* ${userFromMessage.reason}\n🕒 *Tanggal:* ${userFromMessage.date}`, m, {
            mentions: [sender]
        });
        await conn.groupParticipantsUpdate(chatId, [sender], 'remove');
        return;
    }

    // Kick jika user baru join dan ada di blacklist
    if (m.messageStubType === 28 || m.messageStubType === 29) {
        const addedUsers = m.messageStubParameters || [];
        for (let user of addedUsers) {
            const userFromJoin = bl.find(v => v.id === user);
            if (userFromJoin) {
                await conn.reply(chatId, `🚫 @${user.split("@")[0]} dikick karena *masuk Blacklist* saat join.\n📄 *Alasan:* ${userFromJoin.reason}\n🕒 *Tanggal:* ${userFromJoin.date}`, m, {
                    mentions: [user]
                });
                await conn.groupParticipantsUpdate(chatId, [user], 'remove');
            }
        }
    }
};

handler.help = [
    'blacklist <nomor> <alasan>',
    'unblacklist <nomor>',
    'listblacklist',
    'resetblacklist yes'
];
handler.tags = ['group'];
handler.command = ['blacklist', 'unblacklist', 'listbl', 'listblacklist', 'resetblacklist'];
handler.admin = true;
handler.group = true;

module.exports = handler;