const axios = require('axios');

let handler = async (m, { conn, command }) => {
  m.reply(wait);
  try {
    let endpoint = command.toLowerCase() === 'husbu'
      ? 'husbu'   // karakter cowok
      : 'waifu';  // karakter cewek

    let url = `https://api.botcahx.eu.org/api/anime/${endpoint}?apikey=${btc}`;
    let res = await axios.get(url, { responseType: 'arraybuffer' });

    await conn.sendFile(m.chat, res.data, 'anime.jpg', `📸 Random ${command.toUpperCase()}`, m);
  } catch (e) {
    console.log(e);
    conn.reply(m.chat, `⚠️ Gagal mengambil gambar ${command}. Coba lagi nanti.`, m);
  }
};

handler.command = /^(husbu|waifu)$/i;
handler.help = ['husbu', 'waifu'];
handler.tags = ['random'];
handler.limit = true;

module.exports = handler;