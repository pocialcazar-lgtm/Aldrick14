const fs = require('fs');
const fetch = require('node-fetch');
const FileType = require('file-type'); // Tambahkan ini

const handler = async (m, { conn, args, text, usedPrefix, command }) => {
    text = text 
        ? text 
        : m.quoted?.text 
        || m.quoted?.caption 
        || m.quoted?.description 
        || '';

    if (!text) throw `🚩 *Contoh:* ${usedPrefix + command} Lagi Ruwet`;

    let res;
    if (command === 'brat') {
        res = `https://api.botcahx.eu.org/api/maker/brat?text=${encodeURIComponent(text.substring(0, 151))}&apikey=${btc}`;
    } else if (['brat2', 'bratgif', 'bratvid'].includes(command)) {
        res = `https://api.botcahx.eu.org/api/maker/brat-video?text=${encodeURIComponent(text.substring(0, 151))}&apikey=${btc}`;
    } else if (command === 'ttp') {
        res = `https://api.botcahx.eu.org/api/maker/ttp?text=${encodeURIComponent(text.substring(0, 151))}&apikey=${btc}`;
    } else if (command === 'attp') {
        res = `https://api.botcahx.eu.org/api/maker/attp?text=${encodeURIComponent(text.substring(0, 151))}&apikey=${btc}`;
    }

    const fallbackSticker = fs.readFileSync('./media/sticker/emror.webp');

    try {
        const response = await fetch(res);
        if (!response.ok) throw new Error(`❌ HTTP Error ${response.status}`);

        const buffer = await response.buffer();

        // Cek panjang buffer
        if (!buffer || buffer.length < 1000) {
            throw new Error(`❌ Buffer kosong atau terlalu kecil.`);
        }

        // Deteksi format asli buffer
        const fileType = await FileType.fromBuffer(buffer);
        const mime = fileType?.mime || '';

        // Validasi untuk video/gif command
        if (['brat2', 'bratgif', 'bratvid'].includes(command)) {
            if (!/video|gif/.test(mime)) {
                throw new Error(`❌ File bukan video/gif valid. MIME: ${mime}`);
            }

            await conn.sendVideoAsSticker(m.chat, buffer, m, {
                packname: global.packname,
                author: global.author
            });

        } else if (command === 'attp') {
            await conn.sendFile(m.chat, buffer, 'sticker.webp', '', m);

        } else {
            // Default: kirim sebagai stiker gambar
            await conn.sendImageAsSticker(m.chat, buffer, m, {
                packname: global.packname,
                author: global.author
            });
        }

    } catch (e) {
        console.error('[Sticker Error]', e);
        await conn.sendImageAsSticker(m.chat, fallbackSticker, m, {
            packname: global.packname,
            author: global.author
        });
    }
};

handler.command = handler.help = ['brat', 'brat2', 'bratgif', 'bratvid', 'ttp', 'attp'];
handler.tags = ['sticker'];
handler.limit = true;

module.exports = handler;