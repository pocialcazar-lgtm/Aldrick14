module.exports = {
  async before(m, { conn }) {
    if (!m.isGroup) return

    let users = global.db.data.users
    let today = new Date()
    let tgl = String(today.getDate()).padStart(2, '0')
    let bln = String(today.getMonth() + 1).padStart(2, '0')
    let hariIni = `${tgl}-${bln}`

    for (let jid in users) {
      let user = users[jid]
      if (!user.ultah) continue

      let [utTgl, utBln, _] = user.ultah.split('-')
      if (`${utTgl}-${utBln}` === hariIni && !user.ultahSent) {
        await conn.reply(m.chat, `🎉 Selamat ulang tahun @${jid.split('@')[0]}! Semoga panjang umur dan sehat selalu. 🎂`, m, { mentions: [jid] })
        user.ultahSent = true // supaya tidak spam
      }
    }
  }
}