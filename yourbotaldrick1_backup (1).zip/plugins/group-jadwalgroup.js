let moment = require('moment-timezone');

const timeZone = 'Asia/Jakarta';

let handler = async (m, { conn, args, isOwner, isAdmin, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat];
    if (!m.isGroup) throw 'Perintah ini hanya bisa digunakan di grup!';
    if (!(isAdmin || isOwner)) throw 'Perintah ini hanya bisa digunakan oleh admin grup!';

    if (args[0] === 'on') {
        if (args.length < 2) throw `Format salah! Gunakan *${usedPrefix + command} on jamTutup|jamBuka*\nContoh: ${usedPrefix + command} on 21|5`;
        let [closeTime, openTime] = args[1].split('|').map(Number);
        if (isNaN(closeTime) || isNaN(openTime)) throw 'Jam tutup dan buka harus berupa angka!';
        chat.autoGc = { closeTime, openTime };
        chat.groupStatus = 'opened'; // inisialisasi status
        m.reply(`✅ Jadwal group diaktifkan.\nGrup akan *tutup* pukul ${closeTime}:00 dan *buka* pukul ${openTime}:00 WIB.`);
    } else if (args[0] === 'off') {
        delete chat.autoGc;
        delete chat.groupStatus;
        m.reply('❌ Jadwal group dinonaktifkan.');
    } else {
        throw `Format salah! Gunakan:\n• *${usedPrefix + command} on jamTutup|jamBuka*\n• *${usedPrefix + command} off*\nContoh: ${usedPrefix + command} on 21|5`;
    }
};

handler.command = /^jadwalgroup$/i;
handler.help = ['jadwalgroup on jamTutup|jamBuka', 'jadwalgroup off'];
handler.tags = ['group'];
handler.admin = true;
handler.group = true;

module.exports = handler;


const checkGroupsStatus = async (conn) => {
    const currentHour = moment().tz(timeZone).hour();

    for (const chatId of Object.keys(global.db.data.chats)) {
        const chat = global.db.data.chats[chatId];
        if (!chat.autoGc) continue;

        const { closeTime, openTime } = chat.autoGc;

        if (currentHour === closeTime && chat.groupStatus !== 'closed') {
            try {
                await conn.groupSettingUpdate(chatId, 'announcement');
                await conn.sendMessage(chatId, { text: `( OTOMATIS ) 𝖦𝖱𝖮𝖴𝖯 𝖢𝖫𝖮𝖲𝖤, 𝖣𝖠𝖭 𝖠𝖪𝖠𝖭 𝖣𝖨𝖡𝖴𝖪𝖠 𝖩𝖠𝖬 ${openTime}:00 𝖶𝖨𝖡` });
                chat.groupStatus = 'closed';
            } catch (error) {
                console.error(`Error closing group ${chatId}:`, error);
            }
        }

        if (currentHour === openTime && chat.groupStatus !== 'opened') {
            try {
                await conn.groupSettingUpdate(chatId, 'not_announcement');
                await conn.sendMessage(chatId, { text: `( OTOMATIS ) 𝖦𝖱𝖮𝖴𝖯 𝖮𝖯𝖤𝖭, 𝖣𝖠𝖭 𝖠𝖪𝖠𝖭 𝖣𝖨𝖳𝖴𝖳𝖴𝖯 𝖩𝖠𝖬 ${closeTime}:00 𝖶𝖨𝖡` });
                chat.groupStatus = 'opened';
            } catch (error) {
                console.error(`Error opening group ${chatId}:`, error);
            }
        }
    }
};

const interval = 60000;
setInterval(() => {
    checkGroupsStatus(conn);
}, interval);