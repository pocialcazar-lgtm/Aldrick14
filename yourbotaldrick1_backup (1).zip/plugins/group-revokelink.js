let handler = async (m, { conn }) => {
  try {
    // Reset / revoke link grup
    let code = await conn.groupRevokeInvite(m.chat)
    m.reply(`✅ Link grup berhasil direset.\n\n🔗 Link baru: https://chat.whatsapp.com/${code}`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mereset link grup. Pastikan bot adalah admin.')
  }
}

handler.help = ['revokelink']
handler.tags = ['group']
handler.command = /^revokelink$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler